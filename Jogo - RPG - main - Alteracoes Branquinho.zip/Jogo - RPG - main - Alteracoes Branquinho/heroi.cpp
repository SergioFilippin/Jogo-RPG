#include "Heroi.h"
#include <iostream>

Heroi::Heroi(const std::string& nome, int vida, int forca)
    : nome(nome), vida(vida), topoMochila(0), pesoAtualMochila(0) {
    // Inicializar cinto e mochila com ponteiros nulos
    for (int i = 0; i < CAPACIDADE_MAX_CINTO; ++i) {
        cinto[i] = nullptr;
    }
    for (int i = 0; i < CAPACIDADE_MAX_MOCHILA; ++i) {
        mochila[i] = nullptr;
    }
}

bool Heroi::adicionar_item_mochila(Item* item) {
    if (topoMochila < CAPACIDADE_MAX_MOCHILA) {
        mochila[topoMochila++] = item;
        return true;
    }
    return false; // Retorna false quando a mochila está cheia
}

bool Heroi::adicionar_item_cinto(Item* item) {
    for (int i = 0; i < CAPACIDADE_MAX_CINTO; ++i) {
        if (cinto[i] == nullptr) {
            cinto[i] = item;
            return true;
        }
    }
    return false; // Retorna false quando o cinto está cheio
}

Item* Heroi::remover_item_cinto(int indice) {
    if (indice >= 0 && indice < CAPACIDADE_MAX_CINTO && cinto[indice] != nullptr) {
        Item* retirado = cinto[indice];
        cinto[indice] = nullptr;
        return retirado;
    }
    return nullptr; // Posição vazia ou índice inválido
}

Item* Heroi::usar_item_mochila() {
    if (topoMochila > 0) {
        return mochila[--topoMochila]; // Faz a remoção do item do topo da mochila
    }
    return nullptr; // Mochila vazia
}

void Heroi::ataque() {
    std::cout << nome << " está atacando!" << std::endl;
}

void Heroi::receberdano(int dano) {
    vida -= dano;
    if (vida < 0) vida = 0;
    std::cout << nome << " recebeu " << dano << " de dano. Pontos de vida atual: " << vida << std::endl;
}

void Heroi::usarpocao(Item* pocao) {
    vida += 30;
    if (vida > VIDA_MAXIMA) {
        vida = VIDA_MAXIMA;
    }
    std::cout << nome << " usou uma poção! Vida restaurada: " << vida << std::endl;
}
