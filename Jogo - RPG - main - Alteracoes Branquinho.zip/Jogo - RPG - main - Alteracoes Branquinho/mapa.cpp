#include "Mapa.h"
#include <iostream>
#include <cstdlib> // Para a função rand()
#include <ctime>   // Para a função time()

using namespace std;

// Construtor: inicializa o mapa com tamanho fixo ou aleatório
Mapa::Mapa(bool aleatorio, int tamanhoFixo) : posicaoAtual(0) {
    // Inicializar o gerador de números aleatórios
    srand(static_cast<unsigned int>(time(nullptr)));

    if (aleatorio) {
        // Gera tamanho aleatório do caminho
        tamanhoCaminho = MIN_TAMANHO_MAPA + rand() % (MAX_TAMANHO_MAPA - MIN_TAMANHO_MAPA + 1);
        cout << "Tamanho do mapa gerado aleatoriamente: " << tamanhoCaminho << endl;
    } else {
        // Define o tamanho fixo
        tamanhoCaminho = tamanhoFixo;
        cout << "Tamanho do mapa escolhido: " << tamanhoCaminho << endl;
    }

    // Inicializa todas as posições do mapa como vazias
    for (int i = 0; i < tamanhoCaminho; ++i) {
        caminho[i].vazio = true;
        caminho[i].inimigo = nullptr;
        caminho[i].item = nullptr;
    }
}

// Adiciona um inimigo em uma posição específica do mapa
void Mapa::adicionarInimigo(int posicao, Inimigo* inimigo) {
    if (posicao >= 0 && posicao < tamanhoCaminho) {
        caminho[posicao].vazio = false;
        caminho[posicao].inimigo = inimigo;
    }
}

// Adiciona um item em uma posição específica do mapa
void Mapa::adicionarItem(int posicao, Item* item) {
    if (posicao >= 0 && posicao < tamanhoCaminho) {
        caminho[posicao].vazio = false;
        caminho[posicao].item = item;
    }
}

// Move o jogador para o próximo sqm
bool Mapa::moverParaProximaPosicao() {
    if (posicaoAtual < tamanhoCaminho - 1) {
        ++posicaoAtual;
        return true;
    }
    return false; // Se não houver mais posições, retorna falso
}

// Retorna a posição atual do jogador no mapa
Mapa::Sqm Mapa::getPosicaoAtual() const {
    return caminho[posicaoAtual];
}

// Verifica se o jogador chegou ao fim do mapa
bool Mapa::fimDoMapa() const {
    return posicaoAtual == tamanhoCaminho - 1;
}

// Destrutor: limpa memória alocada para inimigos e itens
Mapa::~Mapa() {
    for (int i = 0; i < tamanhoCaminho; ++i) {
        delete caminho[i].inimigo;
        delete caminho[i].item;
    }
}
