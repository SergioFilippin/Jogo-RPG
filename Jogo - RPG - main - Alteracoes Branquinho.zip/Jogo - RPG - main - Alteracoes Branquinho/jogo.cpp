#include "Jogo.h"
#include "mapa.h"
#include <iostream>
#include <cstdlib> // Para rand e srand
#include <ctime>   // Para time

Jogo::Jogo(Heroi* heroi) : heroi(heroi), numInimigos(0), numItens(0), nivelAtual(0) {
    srand(static_cast<unsigned int>(time(nullptr))); // Semente para geração aleatória
}

void Jogo::iniciar() {
    // 1. Exibir menu e escolher nome e atributos do herói
    std::string nomeHeroi;
    int vida = 100; // Valor padrão
    int forca = 10; // Valor padrão

    std::cout << "Bem-vindo ao RPG! Digite o nome do seu herói: ";
    std::cin >> nomeHeroi;

    heroi = new Heroi(nomeHeroi, vida, forca); // Criar o herói

    // 2. Inicializar mapa
    int tamanhoMapa;
    std::cout << "Escolha o tamanho do mapa (1 a 20): ";
    std::cin >> tamanhoMapa;
    if (tamanhoMapa < 1 || tamanhoMapa > 20) {
        tamanhoMapa = 20; // Padrão se valor inválido
    }
    Mapa mapa(tamanhoMapa); // Criar o mapa

    // 3. Gerar inimigos e itens
    gerarInimigos(); // Chamada para gerar inimigos
    gerarItens();    // Chamada para gerar itens

    // 4. Iniciar loop do jogo
    while (!nivelCompleto()) {
        std::cout << "Você está no nível " << nivelAtual + 1 << std::endl;
        // Lógica de movimentação, interação e batalha pode ser adicionada aqui
    }
}

void Jogo::gerarInimigos() {
    // Exemplo de geração de inimigos
    for (int i = 0; i < MAX_INIMIGOS; ++i) {
        Inimigo* novoInimigo = nullptr;
        int tipo = rand() % 3; // Aleatório entre 0 e 2

        if (tipo == 0) {
            novoInimigo = new Inimigo("Morcego Mutante", 50, 10); // Exemplo de atributos
        } else if (tipo == 1) {
            novoInimigo = new Inimigo("Zumbi", 30, 5);
        } else {
            novoInimigo = new Inimigo("Pincher", 40, 7);
        }

        inimigos[numInimigos++] = novoInimigo; // Adicionar o novo inimigo ao array
    }
}

void Jogo::gerarItens() {
    // Exemplo de geração de itens
    for (int i = 0; i < MAX_ITENS; ++i) {
        Item* novoItem = nullptr;
        int tipo = rand() % 2; // Aleatório entre 0 e 1

        if (tipo == 0) {
            novoItem = new Arma("Machado", 5, 15); // Exemplo de atributos
        } else {
            novoItem = new Arma("Espada", 3, 10);
        }

        itens[numItens++] = novoItem; // Adicionar o novo item ao array
    }
}

bool Jogo::nivelCompleto() const {
    // Lógica para verificar se o nível foi completado
    return numInimigos == 0; // Exemplo: nível completo se não há inimigos
}

// Destrutor
Jogo::~Jogo() {
    // Limpar memória alocada para inimigos e itens
    for (int i = 0; i < numInimigos; ++i) {
        delete inimigos[i];
    }
    for (int i = 0; i < numItens; ++i) {
        delete itens[i];
    }
    delete heroi; // Limpar memória do herói
}